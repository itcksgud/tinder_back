const bcrypt = require('bcryptjs');
const User = require('../models/user.model');
const RefreshToken = require('../models/refreshToken.model'); // Mongoose 모델
const {
  generateAccessToken,
  generateRefreshToken,
  verifyRefreshToken,
  revokeRefreshToken,
} = require('../utils/jwt');
const { sendVerificationEmail } = require('../utils/mailer');
const jwt = require('jsonwebtoken');

async function signup(req, res) {
  const { email, username, password } = req.body;
  const exists = await User.findOne({ email });
  if (exists) return res.status(409).json({ msg: '이미 가입됨' });

  const hash = await bcrypt.hash(password, 10);
  const verificationToken = jwt.sign({ email }, process.env.JWT_SECRET, { expiresIn: '15m' });

  const user = await User.create({
    email, username, password: hash,
    verification: { code: verificationToken, expiresAt: Date.now() + 15 * 60e3 },
  });

  sendVerificationEmail(email, verificationToken).catch(console.error);
  res.status(201).json({ msg: '회원가입 완료. 이메일 인증을 해주세요.' });
}

async function verifyEmail(req, res) {
  const { token } = req.query;
  try {
    const { email } = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findOne({ email, 'verification.code': token });
    if (!user) throw new Error();
    if (user.verification.expiresAt < Date.now()) {
      return res.status(400).json({ msg: '토큰 만료' });
    }
    user.isVerified = true;
    user.verification = null;
    await user.save();

    res.json({ msg: '이메일 인증 완료' });
  } catch {
    res.status(400).json({ msg: '인증 실패' });
  }
}

async function login(req, res) {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (!user || !user.isVerified) {
    return res.status(401).json({ msg: '회원가입 또는 인증 필요' });
  }

  const matched = await bcrypt.compare(password, user.password);
  if (!matched) return res.status(401).json({ msg: '비밀번호 틀림' });

  const accessToken = generateAccessToken({ id: user._id });
  const refreshToken = await generateRefreshToken(user._id);

  res.json({
    success: true,
    accessToken,
    refreshToken,
    user: { id: user._id, email: user.email, isVerified: user.isVerified, username: user.username },
  });
}

async function refreshToken(req, res) {
  const { token } = req.body;
  try {
    const userId = await verifyRefreshToken(token);
    const accessToken = generateAccessToken({ id: userId });
    return res.json({ accessToken });
  } catch (err) {
    return res.status(401).json({ msg: err.message });
  }
}

async function logout(req, res) {
  const { token } = req.body;
  try {
    await revokeRefreshToken(token);
    res.json({ msg: '로그아웃 완료' });
  } catch {
    res.status(500).json({ msg: '서버 오류' });
  }
}

module.exports = { signup, verifyEmail, login, refreshToken, logout };
