require('dotenv').config();
const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.GMAIL_USER,
    pass: process.env.GMAIL_PASS,
  }
});

async function sendVerificationEmail(email, token) {
  const url = `${process.env.APP_URL}/verify-email?token=${token}`;
  await transporter.sendMail({
    from: process.env.GMAIL_USER,
    to: email,
    subject: '이메일 인증 안내',
    html: `
      <p>아래 링크를 클릭해 인증해주세요:</p>
      <a href="${url}">${url}</a>
    `
  });
}
module.exports = { sendVerificationEmail };
